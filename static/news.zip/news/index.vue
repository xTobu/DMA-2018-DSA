<template>
    <div class="popup-news-index" style="display:none">
       
      </div>
</template>

<script>
export default {
	
	asyncData({ redirect }) {},
	fetch({ store, params, query, app }) {
		
	},
	head() {
		return {
			title: '最新消息',
		};
	},
	data() {
		return {};
	},
	computed: {
		
	},
	
	methods: {
		
	},
	created() {
		
	},

	mounted() {
	
	},
};
</script>

<style scoped>

</style>

